PMan File:

To compile pman.c:
make

To execute pman.c:
./PMan

To insert inf.c as a program:
bg ./inf test 50

To exit:
ctrl + c
