Building and Running acs.c:

Compile by typing: make
Execute by typing: ./acs <customer.txt>

Input File:
customer.txt:
The first line contains the amount of customers:
In format
1:1,2,30

The first number is id, followed by priority, arrival time and service time.

